CTT rev0.616 is now obsolete. Once you open and save a TAP xml file with CTT rev0.711 or later
you can no longer open it with rev0.616 (or earlier).

CTT rev0.711 replaces the Number of Update register bits with Total Num of Bits field. To globally update this
field click the following:
1. Open the old rev0.616 file of interest.
2. Click on the Configure menu and select Configure TAP tool.
3. Click on the Register Fields tab.
4. Clock on the Update all TAPs button.

CTT rev 0.712 
Enhancement: CTT now supports command line arguments. 
	a.	CTT exe file was changed to remove spaces
		i.	OLD: Chassis TAP Tool.exe
		ii.	NEW: ChassisTapTool.exe
	b.	CTT can be opened with filename (path) without requiring a the user to physically open the file. Examples:
		i.	If no switches are used then CTT window opens.
		ii.	ChassisTapTool.exe A_CTT_Demo_TAPnet5.xml
		iii.	ChassisTapTool.exe C:\ProgramData\Intel\ChassisTapTool\Design\A_CTT_Demo_TAPnet5\A_CTT_Demo_TAPnet5.xml
	c.	CTT can open a file and print the output files.
		i.	If any of these switches are used then no window is opened. 
		ii.	-sysrdl switch will print SystemRDL files to the directory specified in the configuration menu.
		iii.	-collage switch will print Collage files to the directory specified in the configuration menu.
		iv.	-tapbfm switch will print SIP TAP BFM files to the directory specified in the configuration menu.
	d.	Example of all the above:
	e.	Run CTT from a temp directory. Open Cherryview from the Design directory. Apply all switches.
	f.	C:\Users\mwiznero\Documents\2_Chassis\0_DFx\50_Chassis_TAP_Tool\temp\temp2\ChassisTapTool.exe c:\ProgramData\Intel\ChassisTapTool\Design\CHV_ChassisTAPTool_CTT_rev2p3\CHV_ChassisTapTool_CTT_rev2p3.xml -sysrdl -collage -tapbfm